(function(window, undefined) {
  "use strict";
